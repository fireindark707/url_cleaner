# URL Cleaner

A package for removing tracing parameters from URLs. This package supports:
- Automatically updating filtering rules from Adguard.
- Custom filtering rules.
- Host pathname specific filtering.